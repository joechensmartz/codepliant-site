# Avis de confidentialité — [Your Company Name]

> **Document Version:** 1.0  
> **Document Owner:** [Your Company Name]  
> **Next Review Date:** 2027-03-18


**Dernière mise à jour:** 2026-03-18

> Ceci est un avis de confidentialité simplifié. Pour la politique de confidentialité complète, consultez la [Privacy Policy](./PRIVACY_POLICY.md) (en anglais).

---

## Ce que nous collectons

- Adresse e-mail et informations de compte lors de l’inscription ou de la connexion

## Pourquoi nous collectons vos données

- Fournir et exploiter notre service

## Avec qui nous partageons vos données

- Prestataires de services: better-auth, drizzle, next-auth
- Les autorités judiciaires, uniquement si la loi l’exige

Nous ne vendons **jamais** vos données personnelles.

## Vos droits

- Demander l’accès à vos données
- Télécharger une copie de vos données
- Demander la suppression de vos données
- Vous opposer au traitement non essentiel
- Faire rectifier vos données

## Contact

**[your-email@example.com]**

## En savoir plus

- [Privacy Policy](./PRIVACY_POLICY.md) — Politique de confidentialité complète (en anglais)
- [Terms of Service](./TERMS_OF_SERVICE.md)
- [Security Policy](./SECURITY.md)

---

> **Avertissement:** Cet avis de confidentialité a été généré automatiquement par Codepliant à partir d’une analyse du code source. Il doit être vérifié par un conseiller juridique qualifié.
