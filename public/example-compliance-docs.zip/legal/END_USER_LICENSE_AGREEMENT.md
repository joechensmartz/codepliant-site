# End User License Agreement (EULA)

**Effective Date:** 2026-03-18
**Last Updated:** 2026-03-18

**Project:** @ct3a/root

---

## 1. Agreement to Terms

This End User License Agreement ("Agreement") is a legal agreement between you ("User" or "you") and [Your Company Name] ("Company," "we," "us," or "our") governing your use of @ct3a/root and any related software, documentation, updates, and services (collectively, the "Software").

By installing, copying, or otherwise using the Software, you agree to be bound by the terms of this Agreement. If you do not agree to these terms, do not install or use the Software.

## 2. License Grant

Subject to your compliance with this Agreement, [Your Company Name] grants you a limited, non-exclusive, non-transferable, revocable license to:

- Install and use the Software on devices you own or control
- Use the Software for your personal or internal business purposes
- Make a reasonable number of backup copies of the Software

This license does not include any right to sublicense, sell, resell, or distribute the Software to third parties.

## 3. Restrictions

You agree not to, and shall not permit any third party to:

- Copy, modify, or create derivative works based on the Software, except as expressly permitted
- Reverse engineer, disassemble, decompile, or attempt to derive the source code of the Software, except as permitted by applicable law
- Remove, alter, or obscure any proprietary notices, labels, or marks on the Software
- Use the Software for any unlawful purpose or in violation of any applicable laws or regulations
- Rent, lease, lend, sell, or sublicense the Software
- Use the Software to develop a competing product or service
- Circumvent any technical limitations or access controls in the Software
- Use the Software in a manner that could damage, disable, overburden, or impair our servers or networks

## 4. Intellectual Property Rights

The Software and all copies thereof are proprietary to [Your Company Name] and title thereto remains in [Your Company Name]. All rights in the Software not specifically granted in this Agreement are reserved to [Your Company Name].

The Software is protected by copyright laws, international copyright treaties, and other intellectual property laws and treaties. You acknowledge that the Software contains valuable trade secrets and proprietary information belonging to [Your Company Name].

All trademarks, service marks, trade names, and logos associated with the Software are the property of [Your Company Name] or their respective owners.

## 5. Warranty Disclaimer

THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT.

[Your Company Name] DOES NOT WARRANT THAT:

- The Software will meet your specific requirements
- The Software will be uninterrupted, timely, secure, or error-free
- The results obtained from the use of the Software will be accurate or reliable
- Any errors in the Software will be corrected

Any material downloaded or otherwise obtained through the use of the Software is accessed at your own discretion and risk, and you will be solely responsible for any damage to your device or loss of data that results from the download of any such material.

## 6. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL [Your Company Name], ITS OFFICERS, DIRECTORS, EMPLOYEES, AGENTS, OR LICENSORS BE LIABLE FOR:

- Any indirect, incidental, special, consequential, or punitive damages
- Any loss of profits, data, business, or goodwill
- Cost of procurement of substitute goods or services
- Any damages arising out of or related to your use or inability to use the Software

WHETHER BASED ON WARRANTY, CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY, OR ANY OTHER LEGAL THEORY, EVEN IF [Your Company Name] HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

IN NO EVENT SHALL [Your Company Name]'S TOTAL CUMULATIVE LIABILITY TO YOU EXCEED THE AMOUNT YOU PAID FOR THE SOFTWARE IN THE TWELVE (12) MONTHS PRECEDING THE CLAIM, OR ONE HUNDRED DOLLARS (USD $100), WHICHEVER IS GREATER.

## 7. Termination

This Agreement is effective until terminated. Your rights under this Agreement will terminate automatically without notice if you fail to comply with any of its terms.

Upon termination, you must:

- Cease all use of the Software
- Destroy all copies of the Software in your possession or control
- Remove the Software from all devices on which it is installed

[Your Company Name] may also terminate this Agreement at any time by providing written notice. Termination does not relieve you of any obligations incurred prior to termination.

The following sections survive termination: Intellectual Property Rights, Warranty Disclaimer, Limitation of Liability, and Governing Law.

## 8. Export Compliance

You agree to comply with all applicable export and re-export control laws and regulations, including without limitation the Export Administration Regulations maintained by the United States Department of Commerce, trade and economic sanctions maintained by the Treasury Department's Office of Foreign Assets Control ("OFAC"), and the International Traffic in Arms Regulations maintained by the Department of State.

You represent and warrant that:

- You are not located in a country subject to a U.S. Government embargo or designated as a "terrorist-supporting" country
- You are not listed on any U.S. Government list of prohibited or restricted parties
- You will not use the Software for any purposes prohibited by applicable export laws, including nuclear, chemical, or biological weapons proliferation

## 9. Governing Law

This Agreement shall be governed by and construed in accordance with the laws of [Your Jurisdiction], without regard to its conflict of law provisions.

Any legal action or proceeding arising under this Agreement shall be brought exclusively in the courts located in [Your Jurisdiction], and the parties consent to the personal jurisdiction and venue of such courts.

If any provision of this Agreement is found to be unenforceable or invalid, that provision shall be limited or eliminated to the minimum extent necessary so that this Agreement shall otherwise remain in full force and effect.

## 10. Modifications to This Agreement

[Your Company Name] reserves the right to modify this Agreement at any time. We will notify you of material changes by posting the updated Agreement on our website at [https://yoursite.com] or through the Software.

Your continued use of the Software after such modifications constitutes your acceptance of the revised Agreement. If you do not agree with the modified terms, you must stop using the Software.

## 11. Contact Information

If you have questions about this Agreement, please contact us at:

- **Email:** [your-email@example.com]
