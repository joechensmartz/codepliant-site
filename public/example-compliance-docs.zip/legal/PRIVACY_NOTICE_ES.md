# Aviso de privacidad — [Your Company Name]

> **Document Version:** 1.0  
> **Document Owner:** [Your Company Name]  
> **Next Review Date:** 2027-03-18


**Última actualización:** 2026-03-18

> Este es un aviso de privacidad simplificado. Para la política de privacidad completa, consulte la [Privacy Policy](./PRIVACY_POLICY.md) (en inglés).

---

## Qué datos recopilamos

- Correo electrónico e información de cuenta al registrarse o iniciar sesión

## Por qué recopilamos datos

- Proporcionar y operar nuestro servicio

## Con quién compartimos sus datos

- Proveedores de servicios: better-auth, drizzle, next-auth
- Autoridades judiciales, solo cuando la ley lo requiera

**Nunca** vendemos sus datos personales.

## Sus derechos

- Solicitar acceso a sus datos
- Descargar una copia de sus datos
- Solicitar la eliminación de sus datos
- Oponerse al tratamiento no esencial
- Rectificar sus datos personales

## Contacto

**[your-email@example.com]**

## Más información

- [Privacy Policy](./PRIVACY_POLICY.md) — Política de privacidad completa (en inglés)
- [Terms of Service](./TERMS_OF_SERVICE.md)
- [Security Policy](./SECURITY.md)

---

> **Aviso:** Este aviso de privacidad fue generado automáticamente por Codepliant a partir del análisis del código fuente. Debe ser revisado por un asesor legal cualificado.
