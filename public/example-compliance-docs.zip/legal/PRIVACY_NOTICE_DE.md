# Datenschutzhinweis — [Your Company Name]

> **Document Version:** 1.0  
> **Document Owner:** [Your Company Name]  
> **Next Review Date:** 2027-03-18


**Zuletzt aktualisiert:** 2026-03-18

> Dies ist eine vereinfachte Datenschutzerklärung. Die vollständige rechtliche Datenschutzerklärung finden Sie in der [Privacy Policy](./PRIVACY_POLICY.md) (Englisch).

---

## Was wir erfassen

- E-Mail-Adresse und Kontoinformationen bei Registrierung oder Anmeldung

## Warum wir Daten erfassen

- Bereitstellung und Betrieb unseres Dienstes

## Mit wem wir Daten teilen

- Dienstleister: better-auth, drizzle, next-auth
- Strafverfolgungsbehörden nur bei gesetzlicher Verpflichtung

Wir verkaufen Ihre personenbezogenen Daten **niemals**.

## Ihre Rechte

- Auskunft über Ihre gespeicherten Daten verlangen
- Eine Kopie Ihrer Daten herunterladen
- Löschung Ihrer Daten beantragen
- Der nicht-wesentlichen Datenverarbeitung widersprechen
- Ihre Daten berichtigen lassen

## Kontakt

**[your-email@example.com]**

## Weitere Informationen

- [Privacy Policy](./PRIVACY_POLICY.md) — Vollständige Datenschutzerklärung (Englisch)
- [Terms of Service](./TERMS_OF_SERVICE.md)
- [Security Policy](./SECURITY.md)

---

> **Haftungsausschluss:** Dieser Datenschutzhinweis wurde automatisch von Codepliant auf Basis einer Quellcodeanalyse erstellt. Er sollte von einem qualifizierten Rechtsberater überprüft werden.
