# Data Processing Inventory

> **Acme Inc** — Complete Inventory of Data Processing Activities
>
> GDPR Article 30 — Record of Processing Activities Format
>
> Generated on 2026-03-19 by [Codepliant](https://github.com/joechensmartz/codepliant)
> **Document Version:** 1.0  
> **Document Owner:** Acme Inc  
> **Next Review Date:** 2027-03-19

## 1. Data Controller Information

| Field | Value |
|-------|-------|
| **Organization** | Acme Inc |
| **Contact Email** | legal@acme.com |
| **Data Protection Officer** | Jane Mueller (dpo@acme-saas.com) |
| **EU Representative (Art. 27)** | Acme EU Compliance GmbH, Friedrichstr. 123, 10117 Berlin |
| **Website** | https://acme-saas.com |
| **Inventory Date** | 2026-03-19 |
| **Next Review** | 2027-03-19 |
| **Total Processing Activities** | 7 |

## 2. Processing Activities Summary

| Metric | Count |
|--------|-------|
| Total processing activities | 7 |
| High risk activities | 2 |
| Medium risk activities | 3 |
| Low risk activities | 2 |
| Activities with international transfers | 6 |
| Activities with automated decision-making | 1 |

> **DPIA Required:** 2 high-risk processing activities have been identified. Under GDPR Article 35, a Data Protection Impact Assessment is likely required for these activities.

## 3. Detailed Processing Activities

### PA-001: User Authentication & Account Management

| Field | Details |
|-------|---------|
| **Activity ID** | PA-001 |
| **Processing Activity** | User Authentication & Account Management |
| **Purpose of Processing** | Create and manage user accounts, authenticate sessions, handle password resets and SSO flows |
| **Lawful Basis (Art. 6)** | Contract performance (Art. 6(1)(b)) |
| **Categories of Data Subjects** | Registered Users |
| **Categories of Personal Data** | Email address, Name, Password hash, OAuth tokens, Session identifiers, Login timestamps, IP address |
| **Recipients / Processors** | @supabase/supabase-js |
| **Retention Period** | Duration of account + 30 days after deletion request |
| **International Transfers** | Yes — outside EEA |
| **Transfer Safeguards** | Standard Contractual Clauses (SCCs) |
| **Automated Decision-Making** | No |
| **Risk Level** | **Medium** |

### PA-002: Website & Product Analytics

| Field | Details |
|-------|---------|
| **Activity ID** | PA-002 |
| **Processing Activity** | Website & Product Analytics |
| **Purpose of Processing** | Measure product usage, analyze user behavior patterns, improve user experience, track feature adoption |
| **Lawful Basis (Art. 6)** | Consent (Art. 6(1)(a)) or Legitimate interest (Art. 6(1)(f)) |
| **Categories of Data Subjects** | Website Visitors, Registered Users |
| **Categories of Personal Data** | Page views, Click events, Session duration, Device type, Browser, IP address, Referrer URL, Geographic region |
| **Recipients / Processors** | posthog |
| **Retention Period** | 26 months (analytics data), 14 months (cookie identifiers) |
| **International Transfers** | Yes — outside EEA |
| **Transfer Safeguards** | Standard Contractual Clauses (SCCs) |
| **Automated Decision-Making** | No |
| **Risk Level** | **Medium** |

### PA-003: Payment Processing & Billing

| Field | Details |
|-------|---------|
| **Activity ID** | PA-003 |
| **Processing Activity** | Payment Processing & Billing |
| **Purpose of Processing** | Process purchases, manage subscriptions, handle refunds, generate invoices, comply with tax obligations |
| **Lawful Basis (Art. 6)** | Contract performance (Art. 6(1)(b)) / Legal obligation (Art. 6(1)(c)) |
| **Categories of Data Subjects** | Customers |
| **Categories of Personal Data** | Payment card tokens, Billing address, Email, Transaction amounts, Invoice history, Tax ID |
| **Recipients / Processors** | stripe, stripe-ios |
| **Retention Period** | Duration of subscription + 7 years (tax/accounting requirements) |
| **International Transfers** | Yes — outside EEA |
| **Transfer Safeguards** | PCI DSS compliance, Standard Contractual Clauses |
| **Automated Decision-Making** | No |
| **Risk Level** | **High** |

### PA-004: Email Communications

| Field | Details |
|-------|---------|
| **Activity ID** | PA-004 |
| **Processing Activity** | Email Communications |
| **Purpose of Processing** | Send transactional emails (order confirmations, password resets), marketing communications, system notifications |
| **Lawful Basis (Art. 6)** | Contract performance (Art. 6(1)(b)) / Consent for marketing (Art. 6(1)(a)) |
| **Categories of Data Subjects** | Registered Users, Customers, Newsletter Subscribers |
| **Categories of Personal Data** | Email address, Name, Email content, Delivery status, Open/click tracking, Unsubscribe preferences |
| **Recipients / Processors** | resend |
| **Retention Period** | Until unsubscribe (marketing), 90 days delivery logs (transactional) |
| **International Transfers** | Yes — outside EEA |
| **Transfer Safeguards** | Standard Contractual Clauses (SCCs) |
| **Automated Decision-Making** | No |
| **Risk Level** | **Low** |

### PA-005: AI-Powered Features & Processing

| Field | Details |
|-------|---------|
| **Activity ID** | PA-005 |
| **Processing Activity** | AI-Powered Features & Processing |
| **Purpose of Processing** | Provide AI-powered features including content generation, analysis, recommendations, and automated assistance |
| **Lawful Basis (Art. 6)** | Consent (Art. 6(1)(a)) or Contract performance (Art. 6(1)(b)) |
| **Categories of Data Subjects** | Registered Users |
| **Categories of Personal Data** | User prompts, Conversation history, Generated content, Feature interaction data, Feedback signals |
| **Recipients / Processors** | openai |
| **Retention Period** | 30 days for prompts/responses, configurable per service |
| **International Transfers** | Yes — outside EEA |
| **Transfer Safeguards** | Standard Contractual Clauses, Data Processing Addendum with AI provider |
| **Automated Decision-Making** | Yes — see DPIA |
| **Risk Level** | **High** |

### PA-006: Error Monitoring & Application Performance

| Field | Details |
|-------|---------|
| **Activity ID** | PA-006 |
| **Processing Activity** | Error Monitoring & Application Performance |
| **Purpose of Processing** | Track application errors, monitor performance, debug issues, maintain system reliability |
| **Lawful Basis (Art. 6)** | Legitimate interest (Art. 6(1)(f)) |
| **Categories of Data Subjects** | Registered Users, Website Visitors |
| **Categories of Personal Data** | Error stack traces, Request metadata, User agent, IP address, User context (ID, email), Device information |
| **Recipients / Processors** | @sentry/node |
| **Retention Period** | 90 days (error data), 30 days (performance metrics) |
| **International Transfers** | Yes — outside EEA |
| **Transfer Safeguards** | Standard Contractual Clauses (SCCs) |
| **Automated Decision-Making** | No |
| **Risk Level** | **Low** |

### PA-007: Primary Data Storage

| Field | Details |
|-------|---------|
| **Activity ID** | PA-007 |
| **Processing Activity** | Primary Data Storage |
| **Purpose of Processing** | Persistent storage of application data including user profiles, content, settings, and transactional records |
| **Lawful Basis (Art. 6)** | Contract performance (Art. 6(1)(b)) |
| **Categories of Data Subjects** | Registered Users, Customers |
| **Categories of Personal Data** | All user-submitted data as defined by database schema, Timestamps, Relational references |
| **Recipients / Processors** | prisma (managed/self-hosted) |
| **Retention Period** | As defined per data category — see Data Retention Policy |
| **International Transfers** | No |
| **Transfer Safeguards** | Encryption at rest, access controls, regular backups |
| **Automated Decision-Making** | No |
| **Risk Level** | **Medium** |

## 4. Processing Activities Overview Table

| ID | Activity | Legal Basis | Data Types | Risk |
|----|----------|-------------|------------|------|
| PA-001 | User Authentication & Account Management | Contract performance | Email address, Name, Password hash ... | Medium |
| PA-002 | Website & Product Analytics | Consent | Page views, Click events, Session duration ... | Medium |
| PA-003 | Payment Processing & Billing | Contract performance | Payment card tokens, Billing address, Email ... | High |
| PA-004 | Email Communications | Contract performance | Email address, Name, Email content ... | Low |
| PA-005 | AI-Powered Features & Processing | Consent | User prompts, Conversation history, Generated content ... | High |
| PA-006 | Error Monitoring & Application Performance | Legitimate interest | Error stack traces, Request metadata, User agent ... | Low |
| PA-007 | Primary Data Storage | Contract performance | All user-submitted data as defined by database schema, Timestamps, Relational references | Medium |

## 5. Legal Basis Summary

| Legal Basis | Activities Using It |
|-------------|-------------------|
| Contract performance (Art. 6(1)(b)) | PA-001, PA-003, PA-004, PA-007 |
| Consent (Art. 6(1)(a)) or Legitimate interest (Art. 6(1)(f)) | PA-002 |
| Consent (Art. 6(1)(a)) or Contract performance (Art. 6(1)(b)) | PA-005 |
| Legitimate interest (Art. 6(1)(f)) | PA-006 |

## 6. International Data Transfers

The following processing activities involve transfers of personal data outside the European Economic Area:

| Activity | Recipients | Safeguard |
|----------|-----------|-----------|
| PA-001: User Authentication & Account Management | @supabase/supabase-js | Standard Contractual Clauses (SCCs) |
| PA-002: Website & Product Analytics | posthog | Standard Contractual Clauses (SCCs) |
| PA-003: Payment Processing & Billing | stripe, stripe-ios | PCI DSS compliance, Standard Contractual Clauses |
| PA-004: Email Communications | resend | Standard Contractual Clauses (SCCs) |
| PA-005: AI-Powered Features & Processing | openai | Standard Contractual Clauses, Data Processing Addendum with AI provider |
| PA-006: Error Monitoring & Application Performance | @sentry/node | Standard Contractual Clauses (SCCs) |

> All international transfers are conducted in accordance with GDPR Chapter V requirements. Transfer Impact Assessments have been or will be conducted for each transfer mechanism.

## 7. Review & Maintenance

This inventory must be maintained as a living document:

- **Annual review:** Full review of all processing activities by 2027-03-19
- **On new processing:** Update when new services or data processing activities are added
- **On change:** Update when existing processing purposes, legal bases, or retention periods change
- **On incident:** Review after any data breach or regulatory inquiry
- **On request:** Make available to supervisory authorities upon request (GDPR Art. 30(4))

---

*This Data Processing Inventory was auto-generated by [Codepliant](https://github.com/joechensmartz/codepliant) based on automated code analysis. It follows the GDPR Article 30 Record of Processing Activities format. This document must be reviewed and completed by your Data Protection Officer and legal counsel to ensure accuracy.*
