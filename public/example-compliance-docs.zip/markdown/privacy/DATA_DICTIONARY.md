# Data Dictionary

> **Document Version:** 1.0  
> **Document Owner:** [Your Company Name]  
> **Next Review Date:** 2027-03-18


**Last updated:** 2026-03-18

**Project:** @ct3a/root

**Company:** [Your Company Name]

## Related Documents

- Data Flow Map (`DATA_FLOW_MAP.md`)
- Data Retention Policy (`DATA_RETENTION_POLICY.md`)
- Data Classification Report (`DATA_CLASSIFICATION.md`)

---

## 1. Purpose

This document catalogs every data field detected across the **@ct3a/root** application. It serves as the authoritative reference for data mapping required by GDPR Article 30 (Records of Processing Activities), SOC 2 (CC6.1), and internal data governance policies.

## 2. Scope

This dictionary covers data fields from:
- Database schemas (Prisma, Drizzle, Mongoose, TypeORM, SQLAlchemy, Django)
- API routes and request handlers
- Third-party service integrations
- Environment variable configurations

---

## 3. Data Field Catalog

| Field | Source | Type | Sensitivity | Retention | Purpose |
|-------|--------|------|-------------|-----------|---------|
| password hash | better-auth | Authentication | Critical | Until account deletion; hashed at rest | User authentication |
| password_hash | better-auth | Authentication | Critical | Until account deletion; hashed at rest | User authentication |
| password_hash | next-auth | Authentication | Critical | Until account deletion; hashed at rest | User authentication |
| email | better-auth | Contact | High | Until account deletion + 30 days | Account identification |
| email | next-auth | Contact | High | Until account deletion + 30 days | Account identification |
| name | better-auth | Personal Identity | High | Until account deletion + 30 days | User identification |
| name | next-auth | Personal Identity | High | Until account deletion + 30 days | User identification |
| OAuth tokens | better-auth | Session | Medium | Until session expiry | Session management |
| OAuth tokens | next-auth | Session | Medium | Until session expiry | Session management |
| oauth_token | better-auth | Authentication | Medium | Until session expiry or revocation | Third-party authentication |
| oauth_token | next-auth | Authentication | Medium | Until session expiry or revocation | Third-party authentication |
| session data | better-auth | Session | Medium | Until session expiry | Session management |
| session data | next-auth | Session | Medium | Until session expiry | Session management |
| session_token | better-auth | Session | Medium | Until session expiry | Session management |
| session_token | next-auth | Session | Medium | Until session expiry | Session management |
| user_data | drizzle | Application Data | Medium | Per data retention policy | Application functionality |
| API Data Collection | cli/template/extras/src/server/api/routers/post/base.ts | Application Data | Low | Per data retention policy | Application functionality |
| API Data Collection | cli/template/extras/src/server/api/routers/post/with-auth-drizzle.ts | Application Data | Low | Per data retention policy | Application functionality |
| API Data Collection | cli/template/extras/src/server/api/routers/post/with-auth-prisma.ts | Application Data | Low | Per data retention policy | Application functionality |
| API Data Collection | cli/template/extras/src/server/api/routers/post/with-auth.ts | Application Data | Low | Per data retention policy | Application functionality |
| API Data Collection | cli/template/extras/src/server/api/routers/post/with-drizzle.ts | Application Data | Low | Per data retention policy | Application functionality |
| API Data Collection | cli/template/extras/src/server/api/routers/post/with-prisma.ts | Application Data | Low | Per data retention policy | Application functionality |
| Authentication Data | account.password | Application Data | Low | Per data retention policy | Application functionality |
| Contact Information | user.email | Application Data | Low | Per data retention policy | Application functionality |
| Personal Identity Data | better-auth | Application Data | Low | Per data retention policy | Application functionality |
| Personal Identity Data | next-auth | Application Data | Low | Per data retention policy | Application functionality |
| Personal Identity Data | user.name | Application Data | Low | Per data retention policy | Application functionality |
| profile picture | next-auth | Application Data | Low | Per data retention policy | Application functionality |
| Stored User Data | drizzle | Application Data | Low | Per data retention policy | Application functionality |
| Technical Data | session.ipAddress | Application Data | Low | Per data retention policy | Application functionality |
| Technical Data | session.userAgent | Application Data | Low | Per data retention policy | Application functionality |
| user data as defined in schema | drizzle | Application Data | Low | Per data retention policy | Application functionality |
| User-Uploaded Content | GitHub Artifacts | Application Data | Low | Per data retention policy | Application functionality |

---

## 4. Sensitivity Summary

| Level | Count | Description |
|-------|-------|-------------|
| Critical | 3 | Credentials, government IDs, raw payment data — requires encryption at rest and strict access control |
| High | 4 | PII (names, emails, addresses) — requires encryption and consent |
| Medium | 9 | Behavioral data, session data, IP addresses — requires privacy notice |
| Low | 17 | Preferences, metadata, operational data — standard handling |

**Total fields cataloged:** 33

---

## 5. Cross-References

- **Database schema** — Fields detected from Prisma/ORM model definitions
- **API routes** — Data fields accepted via request handlers
- **Auth services** — better-auth, next-auth
- **Database services** — drizzle

---

## 6. Related Documents

- **PRIVACY_POLICY.md** — Public disclosure of data collection practices
- **DATA_RETENTION_POLICY.md** — Detailed retention schedules and deletion procedures
- **DATA_CLASSIFICATION.md** — GDPR sensitivity classification details
- **DATA_FLOW_MAP.md** — Visual representation of data flows between services
- **DSAR_HANDLING_GUIDE.md** — Data subject access request procedures

---

## 7. Maintenance

This data dictionary should be updated:

- When new database models or fields are added
- When new third-party services are integrated
- When data retention policies change
- At minimum **quarterly** as part of compliance review

For questions about this data dictionary, contact [your-email@example.com].

---

*This Data Dictionary was generated by [Codepliant](https://github.com/joechensmartz/codepliant) based on automated code analysis. Review and verify all entries for accuracy. This document does not constitute legal advice.*