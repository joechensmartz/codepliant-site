# Cookie Inventory

> **Document Version:** 1.0  
> **Document Owner:** [Your Company Name]  
> **Next Review Date:** 2027-03-18


**Last updated:** 2026-03-18

**Project:** @ct3a/root
**Organization:** [Your Company Name]

## Related Documents

- Cookie Policy (`COOKIE_POLICY.md`)
- Consent Management Guide (`CONSENT_MANAGEMENT_GUIDE.md`)

---

This document provides a complete inventory of all cookies and similar tracking technologies used by this application. This inventory is required by the ePrivacy Directive (Directive 2002/58/EC, as amended by Directive 2009/136/EC) and supports GDPR transparency requirements.

## Summary

| Category | Count | Consent Required |
|----------|-------|-----------------|
| Strictly Necessary | 8 | No (exempt under ePrivacy Directive Art. 5(3)) |
| Analytics | 0 | Yes |
| **Total** | **8** | |

## Strictly Necessary Cookies

These cookies are essential for the application to function and cannot be disabled. They do not require user consent under Article 5(3) of the ePrivacy Directive.

| Cookie Name | Purpose | Duration | Provider |
|-------------|---------|----------|----------|
| `session_id / connect.sid` | Maintains authenticated user session on the server | Session or configured expiry | First-party |
| `auth_token / jwt` | Stores authentication token for API authorization | Varies (typically 1 hour to 30 days) | First-party |
| `csrf_token / XSRF-TOKEN` | Prevents cross-site request forgery attacks | Session | First-party |
| `refresh_token` | Enables silent re-authentication when access token expires | 30-90 days (varies) | First-party |
| `better-auth.session_token` | Stores session token for Better Auth authentication | 30 days (default) | First-party (Better Auth) |
| `next-auth.session-token` | Stores encrypted session data for NextAuth.js authentication | 30 days (default) | First-party (NextAuth.js) |
| `next-auth.csrf-token` | CSRF protection for NextAuth.js sign-in and sign-out | Session | First-party (NextAuth.js) |
| `next-auth.callback-url` | Stores the callback URL for OAuth redirect | Session | First-party (NextAuth.js) |

## Detected Services

The following services were detected in the codebase that set or use cookies:

### Authentication Services

- **better-auth** — detected in `cli/template/extras/src/app/api/auth/[...all]/route.ts`, `cli/template/extras/src/pages/api/auth/[...all].ts`, `cli/template/extras/src/server/better-auth/client.ts`, `cli/template/extras/src/server/better-auth/config/base.ts`, `cli/template/extras/src/server/better-auth/config/with-drizzle.ts`, `cli/template/extras/src/server/better-auth/config/with-prisma.ts`
- **next-auth** — detected in `cli/template/extras/src/pages/_app/with-auth-trpc-tw.tsx`, `cli/template/extras/src/pages/_app/with-auth-trpc.tsx`, `cli/template/extras/src/pages/_app/with-auth-tw.tsx`, `cli/template/extras/src/pages/_app/with-auth.tsx`, `cli/template/extras/src/pages/index/with-auth-trpc-tw.tsx`, `cli/template/extras/src/pages/index/with-auth-trpc.tsx`, `cli/template/extras/src/server/api/trpc-pages/with-auth-db.ts`, `cli/template/extras/src/server/api/trpc-pages/with-auth.ts`, `cli/template/extras/src/server/auth/index.ts`, `cli/template/extras/src/server/auth/config/base.ts`, `cli/template/extras/src/server/auth/config/with-drizzle.ts`, `cli/template/extras/src/server/auth/config/with-prisma.ts`, `cli/template/extras/src/server/db/schema-drizzle/with-auth-mysql.ts`, `cli/template/extras/src/server/db/schema-drizzle/with-auth-planetscale.ts`, `cli/template/extras/src/server/db/schema-drizzle/with-auth-postgres.ts`, `cli/template/extras/src/server/db/schema-drizzle/with-auth-sqlite.ts`

## Legal Requirements

### ePrivacy Directive (EU)

Under Article 5(3) of the ePrivacy Directive:

- **Strictly necessary cookies** may be set without consent (e.g., session cookies, CSRF tokens)
- **All other cookies** require informed, specific, and freely given consent before being set
- Users must be able to **withdraw consent** as easily as they gave it
- Consent must be obtained **before** cookies are placed (no implied consent)

### GDPR (EU)

- Cookie consent constitutes processing of personal data under GDPR Article 6(1)(a)
- Users have the right to know what cookies are used (this inventory)
- Data collected via cookies is subject to all GDPR rights (access, erasure, portability)

### CCPA/CPRA (California)

- Users must be informed about categories of personal information collected via cookies
- "Do Not Sell or Share My Personal Information" link must be provided if advertising cookies are used
- Global Privacy Control (GPC) signals must be honored

## Inventory Maintenance

This cookie inventory should be reviewed and updated:

- [ ] When adding or removing third-party services
- [ ] When changing authentication providers
- [ ] When adding new tracking or analytics tools
- [ ] At minimum quarterly, or after any significant application change
- [ ] After any audit finding related to cookies or tracking

For questions about this cookie inventory, contact **[your-email@example.com]**.

---

*This cookie inventory was generated by [Codepliant](https://github.com/joechensmartz/codepliant) based on an automated scan of the **@ct3a/root** codebase. It should be reviewed by your legal team to ensure completeness and accuracy. Additional cookies may be set by third-party scripts loaded at runtime that are not detectable through static code analysis.*