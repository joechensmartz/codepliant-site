# Data Mapping Register

> **Document Version:** 1.0
> **Document Owner:** [Your Company Name]
> **Generated:** 2026-03-18 by [Codepliant](https://github.com/joechensmartz/codepliant)
> **Next Review Date:** 2027-03-18

This register provides a complete inventory of personal data processing activities
in compliance with GDPR Article 30 (Records of Processing Activities).

## 1. Data Controller Information

| Field | Details |
|-------|---------|
| **Data Controller** | [Your Company Name] |
| **Contact Email** | [your-email@example.com] |
| **Data Protection Officer** | [Data Protection Officer Name] |
| **DPO Email** | [your-email@example.com] |
| **Register Last Updated** | 2026-03-18 |

## 2. Data Inventory

| # | Data Element | Sensitivity | Source | Storage Location | Shared With | Lawful Basis | Retention |
|---|-------------|-------------|--------|------------------|-------------|--------------|-----------|
| 1 | email | Directly Identifiable | User-provided (registration/form) | better-auth (third-party) | better-auth, next-auth | Contract performance (Art. 6(1)(b)) | Duration of account + 30 days |
| 2 | name | Directly Identifiable | User-provided (registration/form) | better-auth (third-party) | better-auth, next-auth | Contract performance (Art. 6(1)(b)) | Duration of account + 30 days |
| 3 | password hash | Security Credential | Application-collected | better-auth (third-party) | better-auth, next-auth | Contract performance (Art. 6(1)(b)) | Duration of account + 30 days |
| 4 | session data | General | Automatic collection (cookies/SDK) | better-auth (third-party) | better-auth, next-auth | Contract performance (Art. 6(1)(b)) | Duration of account + 30 days |
| 5 | OAuth tokens | Security Credential | Application-collected | better-auth (third-party) | better-auth, next-auth | Contract performance (Art. 6(1)(b)) | Duration of account + 30 days |
| 6 | user data as defined in schema | General | Application-collected | drizzle (third-party) | drizzle | Contract performance (Art. 6(1)(b)) | Duration of account + 30 days |
| 7 | profile picture | General | Application-collected | next-auth (third-party) | next-auth | Contract performance (Art. 6(1)(b)) | Duration of account + 30 days |
| 8 | Personal Identity Data | General | better-auth | Application database | Internal only | To be determined | To be determined |
| 9 | User-Uploaded Content | General | GitHub Artifacts | Application database | Internal only | To be determined | To be determined |
| 10 | Stored User Data | General | drizzle | Application database | Internal only | To be determined | To be determined |
| 11 | Contact Information | General | user.email | Application database | Internal only | To be determined | To be determined |
| 12 | Technical Data | General | session.ipAddress | Application database | Internal only | To be determined | To be determined |
| 13 | Authentication Data | General | account.password | Application database | Internal only | To be determined | To be determined |
| 14 | API Data Collection | General | cli/template/extras/src/server/api/routers/post/base.ts | Application database | Internal only | To be determined | To be determined |

## 3. Data Flow Summary

### Directly Identifiable

| Data Element | Source | Destination |
|-------------|--------|-------------|
| email | User-provided (registration/form) | better-auth, next-auth |
| name | User-provided (registration/form) | better-auth, next-auth |

### Security Credential

| Data Element | Source | Destination |
|-------------|--------|-------------|
| password hash | Application-collected | better-auth, next-auth |
| OAuth tokens | Application-collected | better-auth, next-auth |

### General

| Data Element | Source | Destination |
|-------------|--------|-------------|
| session data | Automatic collection (cookies/SDK) | better-auth, next-auth |
| user data as defined in schema | Application-collected | drizzle |
| profile picture | Application-collected | next-auth |
| Personal Identity Data | better-auth | Application database |
| User-Uploaded Content | GitHub Artifacts | Application database |
| Stored User Data | drizzle | Application database |
| Contact Information | user.email | Application database |
| Technical Data | session.ipAddress | Application database |
| Authentication Data | account.password | Application database |
| API Data Collection | cli/template/extras/src/server/api/routers/post/base.ts | Application database |

## 4. Third-Party Processors

| Processor | Data Shared | Purpose | DPA Status |
|-----------|------------|---------|------------|
| better-auth | email, name, password hash, session data, OAuth tokens | auth | ⬜ To be verified |
| next-auth | email, name, password hash, session data, OAuth tokens, profile picture | auth | ⬜ To be verified |
| drizzle | user data as defined in schema | database | ⬜ To be verified |

## 5. International Data Transfers

| Processor | Transfer Destination | Safeguard Mechanism | Status |
|-----------|---------------------|---------------------|--------|
| better-auth | To be verified | SCCs / Adequacy Decision | ⬜ To be assessed |
| next-auth | To be verified | SCCs / Adequacy Decision | ⬜ To be assessed |
| drizzle | To be verified | SCCs / Adequacy Decision | ⬜ To be assessed |

## 6. Retention Schedule

| Data Category | Retention Period | Deletion Method | Legal Basis for Retention |
|---------------|-----------------|-----------------|--------------------------|
| Directly Identifiable | Duration of account + 30 days | Automated purge + manual verification | Contract performance (Art. 6(1)(b)) |
| Security Credential | Duration of account + 30 days | Automated purge + manual verification | Contract performance (Art. 6(1)(b)) |
| General | Duration of account + 30 days | Automated purge + manual verification | Contract performance (Art. 6(1)(b)) |

---

*This data mapping register is generated from automated code analysis and should be reviewed by your Data Protection Officer and legal team. It may not capture all data processing activities, particularly those conducted outside the scanned codebase. This does not constitute legal advice.*
