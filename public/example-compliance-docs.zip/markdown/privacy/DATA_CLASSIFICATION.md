# Data Classification Report

> **Document Version:** 1.0  
> **Document Owner:** [Your Company Name]  
> **Next Review Date:** 2027-03-18


**Project:** @ct3a/root
**Company:** [Your Company Name]
**Generated:** 2026-03-18
**Classification Standard:** GDPR (General Data Protection Regulation)

## Related Documents

- Data Dictionary (`DATA_DICTIONARY.md`)
- Data Retention Policy (`DATA_RETENTION_POLICY.md`)
- Privacy Policy (`PRIVACY_POLICY.md`)

---

## Summary

| Sensitivity Level | Count | Description |
|-------------------|-------|-------------|
| Special Category (Art. 9) | 0 | Health, biometric, genetic, racial, political, religious, sexual orientation, trade union |
| High | 7 | Financial (PCI), government ID (SSN), authentication credentials |
| Medium | 12 | Contact info (email, phone), identity (name, DOB), location |
| Low | 14 | Behavioral (analytics), technical (IP, device info), preferences |

**Total classified fields:** 33

---

## Detailed Classification

| Field | Source | Sensitivity | GDPR Category | Retention |
|-------|--------|-------------|---------------|----------|
| password hash | better-auth | High | Authentication credential | Until account deletion; rotate regularly |
| OAuth tokens | better-auth | High | Authentication credential | Until account deletion; rotate regularly |
| OAuth tokens | next-auth | High | Authentication credential | Until account deletion; rotate regularly |
| Email addresses, names, profile pictures, and account credentials collected through authentication. names detected in Drizzle ORM table fields: user.name. | better-auth | High | Authentication credential | Until account deletion; rotate regularly |
| Email addresses, names, profile pictures, and account credentials collected through authentication. names detected in Drizzle ORM table fields: user.name. | next-auth | High | Authentication credential | Until account deletion; rotate regularly |
| Email addresses, names, profile pictures, and account credentials collected through authentication. names detected in Drizzle ORM table fields: user.name. | user.name | High | Authentication credential | Until account deletion; rotate regularly |
| passwords detected in Drizzle ORM table fields: account.password. | account.password | High | Authentication credential | Until account deletion; rotate regularly |
| email | better-auth | Medium | Contact — email | Until account deletion or consent withdrawal |
| name | better-auth | Medium | Personal identity — name | Until account deletion |
| email | next-auth | Medium | Contact — email | Until account deletion or consent withdrawal |
| name | next-auth | Medium | Personal identity — name | Until account deletion |
| profile picture | next-auth | Medium | Personal identity — image | Until account deletion |
| email addresses detected in Drizzle ORM table fields: user.email. | user.email | Medium | Contact — email | Until account deletion or consent withdrawal |
| 12 API endpoint(s) accepting user data via MUTATION, QUERY requests. Data fields collected: name, text. | cli/template/extras/src/server/api/routers/post/base.ts | Medium | Personal identity — name | Until account deletion |
| 12 API endpoint(s) accepting user data via MUTATION, QUERY requests. Data fields collected: name, text. | cli/template/extras/src/server/api/routers/post/with-auth-drizzle.ts | Medium | Personal identity — name | Until account deletion |
| 12 API endpoint(s) accepting user data via MUTATION, QUERY requests. Data fields collected: name, text. | cli/template/extras/src/server/api/routers/post/with-auth-prisma.ts | Medium | Personal identity — name | Until account deletion |
| 12 API endpoint(s) accepting user data via MUTATION, QUERY requests. Data fields collected: name, text. | cli/template/extras/src/server/api/routers/post/with-auth.ts | Medium | Personal identity — name | Until account deletion |
| 12 API endpoint(s) accepting user data via MUTATION, QUERY requests. Data fields collected: name, text. | cli/template/extras/src/server/api/routers/post/with-drizzle.ts | Medium | Personal identity — name | Until account deletion |
| 12 API endpoint(s) accepting user data via MUTATION, QUERY requests. Data fields collected: name, text. | cli/template/extras/src/server/api/routers/post/with-prisma.ts | Medium | Personal identity — name | Until account deletion |
| session data | better-auth | Low | Behavioral — analytics | 26 months |
| user data as defined in schema | drizzle | Low | Unclassified data | Review and define retention policy |
| session data | next-auth | Low | Behavioral — analytics | 26 months |
| User-Uploaded Content | GitHub Artifacts | Low | Unclassified data | Review and define retention policy |
| Stored User Data | drizzle | Low | Unclassified data | Review and define retention policy |
| Technical Data | session.ipAddress | Low | Unclassified data | Review and define retention policy |
| Technical Data | session.userAgent | Low | Unclassified data | Review and define retention policy |
| Personal Identity Data | category:Personal Identity Data | Low | Unclassified data | Review and define retention policy |
| User-Uploaded Content | category:User-Uploaded Content | Low | Unclassified data | Review and define retention policy |
| Stored User Data | category:Stored User Data | Low | Unclassified data | Review and define retention policy |
| Contact Information | category:Contact Information | Low | Unclassified data | Review and define retention policy |
| Technical Data | category:Technical Data | Low | Unclassified data | Review and define retention policy |
| Authentication Data | category:Authentication Data | Low | Unclassified data | Review and define retention policy |
| API Data Collection | category:API Data Collection | Low | Unclassified data | Review and define retention policy |


---

## Recommendations

### High Sensitivity Data — 7 field(s)

- **Encrypt at rest and in transit** using industry-standard algorithms (AES-256, TLS 1.2+)
- **Tokenize payment data** — never store raw card numbers (PCI DSS requirement)
- **Hash credentials** with bcrypt, scrypt, or Argon2; never store plaintext passwords
- **Limit access** to personnel with a business need; implement role-based access control
- **Retain per regulatory requirements** (e.g., 7 years for financial records)
- **Regular security audits** and penetration testing recommended

### Medium Sensitivity Data — 12 field(s)

- **Encrypt in transit** (TLS 1.2+); encrypt at rest where feasible
- **Obtain clear consent** before collection; provide opt-out mechanisms
- **Allow user access and deletion** per GDPR Art. 15-17 (right of access, rectification, erasure)
- **Pseudonymize** where possible to reduce risk
- **Define clear retention periods** and automate data deletion

### Low Sensitivity Data — 14 field(s)

- **Encrypt in transit** (TLS 1.2+)
- **Anonymize or aggregate** analytics data where possible
- **Honor Do Not Track / Global Privacy Control** signals
- **Set appropriate retention periods** (typically 90 days for logs, 26 months for analytics)
- **Disclose in privacy policy** even for low-sensitivity data

---

*This classification is auto-generated based on code analysis. It should be reviewed by your legal and security teams. Data classification may change as your application evolves — re-run this scan regularly.*
